# THIRD-PARTY LICENSES — GUNBOND

**游戏 / Game:** GUNBOND
**版本 / Version:** 0.2 (2026-11)
**开发者 / Developer:** 王鼎文 (Wang Dingwen)
**更新 / Updated:** 2026-11-15

---

本文件列出 GUNBOND 随游戏分发的全部第三方素材及其授权。
完整许可原文见本目录（`LICENSES/`）。

This file lists every third-party asset shipped with GUNBOND and its license.
Full license texts are in the `LICENSES/` folder.

---

## 1. 美术 / Art

### KayKit — CC0 1.0 Universal

| 项 | 内容 |
|---|---|
| 作者 | Kay Lousberg — https://kaylousberg.com · https://kaylousberg.itch.io |
| 使用包 | Skeletons Character Pack · Dungeon Remastered · Adventurers |
| 授权 | **CC0 1.0 Universal**（公有领域贡献，可商用、可修改，不要求署名） |
| 用途 | 敌人模型（跑怪 / 战士 / 法师 / 死灵法师 / 巨像）、场景道具、动画与控制器 |
| 许可链接 | https://creativecommons.org/publicdomain/zero/1.0/ |
| 备注 | 原包内未保存 LICENSE 文件；本目录 `KayKit-SOURCE-素材来源.md` 为来源留证 |

### Kenney — CC0 1.0 Universal

| 项 | 内容 |
|---|---|
| 作者 | Kenney — https://www.kenney.nl |
| 使用包 | Cube Pets · Mini Dungeon · Mini Forest · Blaster Kit |
| 授权 | **CC0 1.0**（可商用，署名非强制；本项目仍致谢） |
| 用途 | 熊敌人 · 场景件 · 枪械件 |

### 自制 / Original

以下资产由开发者自行制作，著作权归开发者所有：

- `PuffSprite.png` —— 受击/死亡粒子贴图（2026-11-15 程序化生成）
- `FluffParticleMaterial` —— 粒子材质配置
- 全部程序化 VFX（枪口火焰、爆炸、命中火花、骨屑、地洞、雾眼等）
- 地板/墙体材质与场景配色
- 准星（自绘十字线，未使用 AI 生成图）

---

## 2. 音频 / Audio

### Kenney — CC0 1.0 Universal

| 包 | 内容 | 用途 |
|---|---|---|
| impact-sounds | 撞击音 | 命中 / 击杀 |
| interface-sounds | 界面音 | UI 按钮 / 面板 |
| digital-audio | 数字音 | 界面反馈 |
| sci-fi-sounds | 科幻音 | 元素效果 |
| rpg-audio | RPG 音 | 拾取 / 成长 |

授权：**CC0 1.0**，可商用，署名非强制。

### 自制程序化合成 / Original Procedural Synthesis

以下全部由开发者用代码合成，**零授权义务**：

| 类别 | 说明 |
|---|---|
| 枪械开火 | 5 把枪 × 3 变体（AR / FT / GL / SG / SR） |
| 霜冻枪声 | 程序化合成，0.20s（短于射击间隔 0.267s） |
| 敌人受伤 / 死亡 | 骨骼咔哒 / 塌散，每事件 3 变体 |
| 玩家受伤 / 死亡 | 装置断电式下坠 |
| BGM | 战斗 / 菜单 / 深层 / 首领 4 首循环曲 + 首领登场音 |
| 环境音 | 风 / 雨 / 低频层 |

**响度标准**（`ASSETS_CREDITS §2.3b`）：枪械 −23.1 dBFS，火焰枪 −26.9 dBFS。

> **未使用任何第三方 BGM**（未使用 Pixabay / incompetech / Freesound 素材）。

---

## 3. 字体 / Fonts

| 字体 | 作者 | 授权 | 用途 | 许可文件 |
|---|---|---|---|---|
| **Noto Sans SC** | Google / Adobe | **SIL OFL 1.1** | 中文界面 | `OFL-1.1-NotoSansSC.txt` |
| **LuckiestGuy** | Astigmatic (Google Fonts) | **Apache License 2.0** ⚠️ 要求署名 | HUD 数字 / 英文标题 | `Apache-2.0-LuckiestGuy.txt` |
| **LiberationSans** | Red Hat / Google | **SIL OFL 1.1** | TextMeshPro 内置回退 | `OFL-1.1-LiberationSans.txt` |

> ⚠️ **Apache 2.0 要求**：分发时必须附带许可全文并提供署名。
> 本项目已在**游戏内「致谢」页**署名，并在本目录附带完整许可原文 —— 两项均已满足。

---

## 4. 引擎与官方包 / Engine & Unity Packages

Unity 2022.3.62f3c1 + 以下随编辑器授权附带的官方包：

- Universal Render Pipeline (URP) 14.0.12
- TextMeshPro 3.0.7
- uGUI 1.0.0
- Timeline 1.7.7
- AI Navigation 1.1.7
- Visual Scripting 1.9.4
- 以及 `com.unity.modules.*` 内置模块（Audio / Physics / Particles / Animation / UI 等）

授权：**Unity Companion License / Unity Personal 授权** —— 可随基于 Unity 构建的产品分发。

---

## 5. 未使用但曾出现在工程中的素材（免责声明）

| 素材 | 状态 |
|---|---|
| Unity Survival Shooter 教程资产（Environment / Lights / Player.fbx） | **已于 2026-11-14 全部移出** `Assets\`，guid 零残留 |
| Castle Pack 爆炸特效包 | **已不被引用**（全部换自制程序化特效）；文件仍存于 `_Imported\VFX\`，**不随包分发** |
| Zombunny / ZomBear / Hellephant 敌人模型 | **已全部替换**为 KayKit Skeletons + Kenney Cube Pets |
| TextMesh Pro 示例场景 | **不随包分发** |

---

## 6. 生成式 AI 声明 / Generative AI Disclosure

**本游戏不包含任何生成式 AI 生成的内容。**

- 全部美术：KayKit / Kenney（CC0）或开发者自制
- 全部音频：Kenney（CC0）或开发者程序化合成
- 全部字体：SIL OFL 1.1 / Apache 2.0
- 准星：开发者自绘（早期曾有一张 AI 生成图，已于 2026-09 替换并删除）

> 开发过程中使用过 AI 辅助（文档整理 / 代码重构建议），但**未产生随游戏交付的内容**，按 Steam 政策无需披露。

---

## 7. 联系 / Contact

如有授权疑问，请联系：**（上架前填写支持邮箱）**

---

*本文件随游戏分发。完整许可原文见 `LICENSES/` 目录。*
*This file ships with the game. Full license texts are in `LICENSES/`.*
