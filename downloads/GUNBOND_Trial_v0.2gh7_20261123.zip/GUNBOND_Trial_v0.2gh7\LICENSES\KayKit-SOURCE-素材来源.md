# SOURCE — KayKit 素材来源记录

本目录素材来自 **KayKit**（作者 Kay Lousberg · https://kaylousberg.com · https://kaylousberg.itch.io）。

| 项 | 内容 |
|---|---|
| 使用包 | Skeletons Character Pack · Dungeon Remastered · Adventurers（`Art\KayKit\Skeletons / Dungeon / Adventurers`） |
| 授权 | **CC0 1.0 Universal（公有领域贡献）** —— 可商用、可修改、**不要求署名** |
| 授权原文 | https://creativecommons.org/publicdomain/zero/1.0/ |
| 入库方式 | 免费包直接下载解压（2026-10 期间） |
| 游戏内用途 | 敌人骨骼模型（跑怪 / 战士 / 法师 / 死灵法师 / 巨像）、场景道具、动画与控制器 |
| 需署名 | 不需要（CC0）；本文件仅作来源留证，便于上架审核答复 |

> 注：工程内**没有保存 KayKit 原始 license 文件**。上架前建议从官网包内把 `LICENSE.txt` 复制到本目录（与 Kenney 的 `License_CC0.txt` 一致的做法）。
