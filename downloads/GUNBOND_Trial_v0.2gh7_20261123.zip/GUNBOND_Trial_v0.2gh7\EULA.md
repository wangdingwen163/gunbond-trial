# GUNBOND 最终用户许可协议 / End User License Agreement

**最后更新 / Last updated:** 2026-11-15
**适用版本 / Applies to:** GUNBOND v0.2 及后续版本
**许可方 / Licensor:** 王鼎文 (Wang Dingwen)
**被许可方 / Licensee:** 你（购买或合法获得本游戏的个人）

---

## 中文版

### 1. 许可授予

在遵守本协议的前提下，许可方授予你一项**个人的、非独占的、不可转让的、可撤销的**许可，允许你：

- 在你拥有的设备上安装并游玩本游戏
- 为个人备份目的制作副本
- 在直播、视频、截图等形式中展示本游戏（无论是否盈利），条件是不得声称游戏由你开发

### 2. 限制

你**不得**：

- 对本游戏进行反向工程、反编译、反汇编，或试图获取源代码（法律明确允许的情形除外）
- 修改、翻译、改编本游戏，或基于本游戏创作衍生作品并分发
- 出售、出租、出借、再分发本游戏或其副本
- 移除或规避本游戏的任何版权声明、许可声明或技术保护措施
- 将本游戏的素材（美术 / 音频 / 字体）单独提取并用于其他项目

### 3. 所有权

本游戏及其全部内容（代码、美术、音频、文本）的著作权归许可方所有。

游戏内使用的第三方素材（KayKit / Kenney / Noto Sans SC / LuckiestGuy 等）的权利归其各自作者所有，详见随游戏附带的 `THIRD_PARTY_LICENSES.md` 与 `LICENSES/` 目录。

### 4. 第三方组件

本游戏包含按 CC0 1.0、SIL OFL 1.1、Apache License 2.0 授权的第三方素材。这些素材的授权条款优先于本协议中与之冲突的部分。完整清单与许可原文见 `THIRD_PARTY_LICENSES.md` 和 `LICENSES/`。

### 5. 免责声明

**本游戏按"现状"提供，不附带任何明示或默示的担保**，包括但不限于适销性、特定用途适用性和不侵权的担保。

许可方不保证本游戏无错误、不中断，或与你的硬件/系统完全兼容。

### 6. 责任限制

在适用法律允许的最大范围内，许可方不对任何间接的、附带的、特殊的、惩罚性的或后果性的损害承担责任，包括但不限于数据丢失、利润损失、业务中断。

许可方对全部损害的总责任不超过你为本游戏实际支付的金额。

### 7. 终止

如果你违反本协议任何条款，本许可自动终止。终止后你必须停止使用并删除本游戏的所有副本。

### 8. 适用法律

本协议适用**中华人民共和国法律**。因本协议产生的争议，双方应友好协商解决；协商不成的，提交许可方所在地有管辖权的法院。

### 9. 可分割性

本协议任何条款被认定无效或不可执行，不影响其余条款的效力。

### 10. 联系方式

邮箱：**（上架前填写）**

---

## English Version

### 1. Grant of License

Subject to your compliance with this Agreement, the Licensor grants you a **personal, non-exclusive, non-transferable, revocable** license to:

- Install and play the Game on devices you own
- Make copies for personal backup purposes
- Display the Game in streams, videos, and screenshots (monetized or not), provided you do not claim to have developed it

### 2. Restrictions

You **may not**:

- Reverse engineer, decompile, disassemble, or attempt to derive the source code (except where explicitly permitted by law)
- Modify, translate, adapt the Game, or create and distribute derivative works
- Sell, rent, lend, or redistribute the Game or copies of it
- Remove or circumvent any copyright notice, license notice, or technical protection measure
- Extract the Game's assets (art / audio / fonts) for use in other projects

### 3. Ownership

All copyright in the Game and its contents (code, art, audio, text) is owned by the Licensor.

Third-party assets used in the Game (KayKit / Kenney / Noto Sans SC / LuckiestGuy, etc.) remain the property of their respective authors. See `THIRD_PARTY_LICENSES.md` and the `LICENSES/` folder shipped with the Game.

### 4. Third-Party Components

The Game includes third-party assets licensed under CC0 1.0, SIL OFL 1.1, and Apache License 2.0. Those license terms prevail over any conflicting terms in this Agreement. See `THIRD_PARTY_LICENSES.md` and `LICENSES/` for the full list and license texts.

### 5. Disclaimer of Warranty

**The Game is provided "AS IS", without any express or implied warranty**, including but not limited to warranties of merchantability, fitness for a particular purpose, and non-infringement.

The Licensor does not warrant that the Game will be error-free, uninterrupted, or fully compatible with your hardware or system.

### 6. Limitation of Liability

To the maximum extent permitted by applicable law, the Licensor shall not be liable for any indirect, incidental, special, punitive, or consequential damages, including but not limited to loss of data, loss of profits, or business interruption.

The Licensor's total liability for all damages shall not exceed the amount you actually paid for the Game.

### 7. Termination

This license terminates automatically if you breach any term of this Agreement. Upon termination you must stop using and delete all copies of the Game.

### 8. Governing Law

This Agreement is governed by the laws of the **People's Republic of China**. Disputes arising from this Agreement shall first be resolved through friendly negotiation; failing that, they shall be submitted to a competent court at the Licensor's place of residence.

### 9. Severability

If any provision of this Agreement is held invalid or unenforceable, the remaining provisions remain in full force.

### 10. Contact

Email: **（to be filled before release）**

---

*本协议随游戏分发。购买或游玩即表示你接受本协议。*
*This Agreement ships with the Game. Purchasing or playing constitutes acceptance.*
