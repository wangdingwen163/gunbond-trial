# LICENSES 目录索引

本目录存放 GUNBOND 随游戏分发的**全部第三方许可原文**。
The full license texts for every third-party asset shipped with GUNBOND.

**Apache License 2.0 要求分发时附带许可全文** —— 本目录即为此目的而存在。
**Apache License 2.0 requires the full text to accompany distribution** — that is why this folder exists.

---

## 文件对照表 / File index

| 文件 | 授权 | 对应素材 | 使用位置 |
|---|---|---|---|
| `Apache-2.0-LuckiestGuy.txt` | **Apache License 2.0**（要求署名） | LuckiestGuy 字体 | HUD 数字 / 英文标题 |
| `OFL-1.1-NotoSansSC.txt` | SIL OFL 1.1 | Noto Sans SC 字体 | 全部中文界面 |
| `OFL-1.1-LiberationSans.txt` | SIL OFL 1.1 | LiberationSans 字体 | TextMeshPro 内置回退 |
| `Kenney-CC0-blaster-kit.txt` | CC0 1.0 | Blaster Kit（枪械件） | 枪模型部件 |
| `Kenney-CC0-cube-pets.txt` | CC0 1.0 | Cube Pets（熊敌人） | Enemy_Bear_Kenney |
| `Kenney-CC0-mini-dungeon.txt` | CC0 1.0 | Mini Dungeon（场景件） | 地牢场景道具 |
| `Kenney-CC0-mini-forest.txt` | CC0 1.0 | Mini Forest（场景件） | 植被/场景道具 |
| `Kenney-CC0-audio-impact.txt` | CC0 1.0 | impact-sounds | 命中 / 击杀音 |
| `Kenney-CC0-audio-interface.txt` | CC0 1.0 | interface-sounds | UI 按钮音 |
| `Kenney-CC0-audio-digital.txt` | CC0 1.0 | digital-audio | 界面反馈音 |
| `Kenney-CC0-audio-scifi.txt` | CC0 1.0 | sci-fi-sounds | 元素效果音 |
| `Kenney-CC0-audio-rpg.txt` | CC0 1.0 | rpg-audio | 拾取 / 成长音 |
| `KayKit-SOURCE-素材来源.md` | CC0 1.0（来源留证） | KayKit Skeletons / Dungeon / Adventurers | 敌人模型 / 场景 / 动画 |

---

## 缺失说明 / Missing originals

| 素材 | 情况 |
|---|---|
| **KayKit** | CC0 1.0，**不要求署名，也不要求附全文**。原包内未保存 LICENSE 文件，本目录以 `KayKit-SOURCE-素材来源.md` 记录来源（作者 / 包名 / 授权链接 / 用途），便于上架审核答复。 |
| **Kenney** | 官方包内自带简版 `License_CC0.txt`（含 CC0 链接与"可商用"声明），已按包逐一复制。CC0 1.0 全文：https://creativecommons.org/publicdomain/zero/1.0/legalcode |

---

## 未随包分发的素材 / Not shipped

下列素材曾出现在工程中，但**不随游戏分发**，因此不在本目录：

- Unity Survival Shooter 教程资产 —— 2026-11-14 全部移出 `Assets\`
- Castle Pack 爆炸特效包 —— 已换自制程序化特效，文件留在 `_Imported\VFX\`（不进 build）
- TextMesh Pro 示例场景 —— 不进 build
- Zombunny / ZomBear / Hellephant —— 已全部替换为 KayKit + Kenney

---

## 游戏内入口 / In-game entry

游戏主菜单 → **致谢（Credits）** 页列有全部署名与本目录说明。

---

*本目录随游戏分发，位于游戏安装目录根下。*
*This folder ships with the game, at the root of the installation directory.*
